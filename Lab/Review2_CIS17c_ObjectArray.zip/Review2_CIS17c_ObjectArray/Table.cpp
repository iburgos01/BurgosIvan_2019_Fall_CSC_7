/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Table.h"

using namespace std;

Table::Table(unsigned int szRow, unsigned int szCol){
    this->szRow=szRow;
    this->szCol=szCol;
    
    columns = new RowAray*[this->szRow];
    
    for(int i=0;i<this->szRow;i++){
        columns[i]= new RowAray[this->szCol];
    }
}

Table::Table(const Table& copy){
    szRow=copy.szRow;
    szCol=copy.szCol;
    
    columns=new *RowAray[szRow];
    
    for(int i=0;i<szRow;i++){
        columns[i] = new RowAray[szCol];
    }
    
    for(int i=0;i<szRow;i++){
        for(int j=0;j<szCol;j++){
            columns[i][j]=copy.columns[i][j];
        }
    }
} 

Table::~Table(){
    for(int i=0;i<szRow;i++){
        delete columns[i];
    }
    
    delete columns;
}
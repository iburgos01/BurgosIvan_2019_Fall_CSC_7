/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include<cstdlib>

#include "RowAray.h"

using namespace std;

RowAray::RowAray(unsigned int size){
    this->size=size;
    
    rowData=new int[this->size];
    
    for(int i=0;i<size;i++){
        rowData[i]=rand()%90+10;
    }
    
}

RowAray::~RowAray(){
    delete []rowData;
}

void RowAray::setData(int spot, int value){
    if(spot>=0&&spot<size){
        rowData[spot]=value;
    }
    else rowData[0]=0;
}
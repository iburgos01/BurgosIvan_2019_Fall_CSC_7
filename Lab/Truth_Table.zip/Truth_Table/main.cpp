/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on September 12, 2019, 9:34 AM
 */

#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char** argv) {
    //Output a Truth Table
    cout<<"P Q ~P ~Q P&&Q P||Q P^Q (P^Q)^Q (P^Q)^P !(P&&Q) !P||!Q !(P||Q) !P^!Q"<<endl;
    cout<<"T T  F  F   T    T   F      T       T       F      F      F      F  "<<endl;
    cout<<"T F  F  T   F    T   T      T       F       T      T      F      T  "<<endl;
    cout<<"F T  T  F   F    T   T      F       T       T      T      F      T  "<<endl;
    cout<<"F F  T  T   F    F   F      T       T       T      T      T      F  "<<endl;
        
    
    return 0;
}


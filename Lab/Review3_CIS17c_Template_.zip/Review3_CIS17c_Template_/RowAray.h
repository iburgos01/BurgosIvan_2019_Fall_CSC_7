/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   RowAray.h
 * Author: rcc
 *
 * Created on October 3, 2019, 9:34 AM
 */

#ifndef ROWARAY_H
#define ROWARAY_H

#include <cstdlib>

#include "Table.h"
using namespace std;

template<class T>
class RowAray{
    protected:
        int size;
        T *rowData;
    public:
        RowAray(int);
        virtual ~RowAray();
        int getSize()const{return size;}
        T getData(int i)const{
            if(i>=0&&i<size)return rowData[i];
            else return 0;}
        void setData(int,T);
};

template<class T>
RowAray<T>::RowAray(int size){
    this->size=size;
    
    rowData= new T[this->size];
    
    for(int i=0;i<this->size;i++){
        rowData[i]=rand()%90+10;
    }
}

template<class T>
void RowAray<T>::setData(int n, T val){
    if(n>=0&&n<size)
        rowData[n]=val;
    else rowData[0]=0;
};

template<class T>
RowAray<T>::~RowAray(){
    delete []rowData;
};

#endif /* ROWARAY_H */


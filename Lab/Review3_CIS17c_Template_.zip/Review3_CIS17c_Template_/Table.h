/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Table.h
 * Author: rcc
 *
 * Created on October 3, 2019, 9:34 AM
 */

#ifndef TABLE_H
#define TABLE_H

#include "RowAray.h"
using namespace std;

template<class T>
class Table{
    protected:
        int szRow;
        int szCol;
        RowAray<T> **columns;
    public:
        Table(unsigned int,unsigned int);
        Table(const Table<T> &);
        virtual ~Table();
        int getSzRow()const {return szRow;}
        int getSzCol()const {return szCol;}
        T getData(int,int)const;
        void setData(int,int,T);
        Table<T> operator+(const Table<T> &);
};

template<class T>
Table<T>::Table(unsigned int szRow, unsigned int szCol){
    this->szRow=szRow;
    this->szCol=szCol;
    
    columns= new RowAray<T>*[this->szRow];
    
    for(int i=0;i<szRow;i++){
        columns[i]=new RowAray<T>(this->szCol);
    }
} 

template<class T>
Table<T>::Table(const Table<T>& tab1){
    szRow=tab1.szRow;
    szCol=tab1.szCol;
    
    columns = new RowAray<T>*[szRow];
    
    for(int i=0;i<szRow;i++){
        columns[i] = tab1.columns[i];
    }
}

template<class T>
T Table<T>::getData(int row, int col) const{
    if(row>=0&&row<szRow){
        return columns[row]->getData(col);
    }
    else columns[0]->getData(0);
}

template<class T>
void Table<T>::setData(int row, int col, T val){
    if(row>=0&&row<szRow){
        columns[row]->setData(col,val);
    }
    else columns[0]->setData(0,0);
}

template<class T>
Table<T>::~Table(){
    for(int i=0;i<szRow;i++){
        delete columns[i];
    }
    
    delete []columns;
}

template<class T>
Table<T> Table<T>::operator +(const Table<T>& tab2){
    Table<T> tab3;
    T val;
    for(int i=0;i<szRow;i++){
        for(int j=0;j<szCol;j++){
            val=columns[i]->getData(j)+tab2.columns[i]->getData(j);
            tab3[i].columns[i]->setData(j,val);
        }
    }
    
    return tab3;
    
}

#endif /* TABLE_H */


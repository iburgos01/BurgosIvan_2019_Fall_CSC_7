/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Link.h
 * Author: rcc
 *
 * Created on September 26, 2019, 9:38 AM
 */

#ifndef LINK_H
#define LINK_H

struct Link{
    int data;
    Link *ptr;
};

//class Link{
//    private:
//        int data;
//        int size;
//        Link *ptr;
//    public:
//        Link(int);
//        ~Link();
//        void pop_front();
//        void pop_back();
//        Link push_front(Link,int);
//        Link push_back(Link,int);
//        void prntLst(Link);
//        
//};

#endif /* LINK_H */


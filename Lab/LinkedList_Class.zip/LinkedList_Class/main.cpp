/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  Hello World Template
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here
#include "Link.h"
//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
Link *filLnk(int);
void prntLst(Link *);
void dstryLst(Link *);
Link *push_front(Link *,int);
Link *findBck(Link);
Link *push_back(Link *,int);
Link *pop_front(Link *);
Link *pop_back(Link *);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    Link *list;
    //Input or initialize values Here
    list=filLnk(20);
    //Process/Calculations Here
    
    //Output Located Here
    prntLst(list);
    list=push_front(list,999);
    prntLst(list);
    list=push_back(list,-999);
    prntLst(list);
    list=pop_back(list);
    prntLst(list);
    
    //Clean up
    dstryLst(list);
    //Exit
    return 0;
}

Link *pop_back(Link *list){
    if(!list)return 0;
    Link *front=list,*back;
    while(front->ptr){
        back=front;
        front=front->ptr;
    }
    
    delete front;
    back->ptr=0;
    
    return list;
}

Link *pop_front(Link *list){
    
}

Link *findBck(Link *list){
    Link *front=list;
    Link *back=new Link;
    while(front){
        back=front;
        front=front->ptr;
    }
    
    return back;
}


Link *push_back(Link *list, int val){
    Link *back=new Link;
    back->data=val;
    back->ptr=0;
    Link *end=findBck(list);
    end->ptr=back;
    
    return list;
    
}

Link *push_front(Link *list,int val){
    Link *front=new Link;
    front->data=val;
    front->ptr=list;
    
    return front;
}

void dstryLst(Link *list){
    Link *front=list;
    while(front){
        Link *temp=front;
        front=front->ptr;
        delete []temp;
    }
}

void prntLst(Link *list){
    Link *front=list;
    while(front){
        cout<<front->data<<endl;
        front=front->ptr;
    }
    cout<<endl;
}
Link *filLnk(int size){
    Link *list = new Link[size];
    for(int i=0;i<size;i++){
        list[i].data=i+1;
        list[i].ptr=&list[i+1];
    }
    list[size-1].data=size;
    list[size-1].ptr=0;
    
    return list;
}
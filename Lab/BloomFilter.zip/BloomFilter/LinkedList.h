/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   LinkedList.h
 * Author: rcc
 *
 * Created on October 31, 2019, 10:03 AM
 */

#ifndef LINKEDLIST_H
#define LINKEDLIST_H

using namespace std;

class LinkedList{
    private:
        struct Link{
            string info;
            Link *linkptr;
                    
        };
        int count;
    public:
        void pushBk(string);
        void countUp();
        string getInfo();
        int getCount();
};

#endif /* LINKEDLIST_H */


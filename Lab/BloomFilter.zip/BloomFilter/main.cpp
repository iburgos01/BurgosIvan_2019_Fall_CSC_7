/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  Bloom filter test
 */

//System Libraries Here
#include <iostream>
#include <string>


using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
unsigned int RSHash  (const string& str);
unsigned int JSHash  (const string& str);
unsigned int PJWHash (const string& str);
unsigned int ELFHash (const string& str);
unsigned int BKDRHash(const string& str);
unsigned int SDBMHash(const string& str);
unsigned int DJBHash (const string& str);
unsigned int DEKHash (const string& str);
unsigned int BPHash  (const string& str);
unsigned int FNVHash (const string& str);
unsigned int APHash  (const string& str);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    string info;
    const int SIZE=15;
    bool test[SIZE];
    //Input or initialize values Here
    cin>>info;
    //Process/Calculations Here
    
    //Output Located Here
    cout << endl;
    cout << "General Purpose Hash Function Algorithms Test" << endl;
    cout << "By Arash Partow - 2002        " << endl;
    cout << "Key: "                          << info           << endl;
    cout << " 1. RS-Hash Function Value:   " << RSHash  (info)%15 << endl;
    cout << " 2. JS-Hash Function Value:   " << JSHash  (info)%15 << endl;
    cout << " 3. PJW-Hash Function Value:  " << PJWHash (info)%15 << endl;
    cout << " 4. ELF-Hash Function Value:  " << ELFHash (info)%15 << endl;
    cout << " 5. BKDR-Hash Function Value: " << BKDRHash(info)%15 << endl;
    cout << " 6. SDBM-Hash Function Value: " << SDBMHash(info)%15 << endl;
    cout << " 7. DJB-Hash Function Value:  " << DJBHash (info)%15 << endl;
    cout << " 8. DEK-Hash Function Value:  " << DEKHash (info)%15 << endl;
    cout << " 9. FNV-Hash Function Value:  " << FNVHash (info)%15 << endl;
    cout << "10. BP-Hash Function Value:   " << BPHash  (info)%15 << endl;
    cout << "11. AP-Hash Function Value:   " << APHash  (info)%15 << endl;

    //Exit
    return 0;
}

int strToByte(string info){
    char val;
    for(int i=0;i<info.length();i++){
        val = info[i];
        
    }
}

/*
 **************************************************************************
 *                                                                        *
 *          General Purpose Hash Function Algorithms Library              *
 *                                                                        *
 * Author: Arash Partow - 2002                                            *
 * URL: http://www.partow.net                                             *
 * URL: http://www.partow.net/programming/hashfunctions/index.html        *
 *                                                                        *
 * Copyright notice:                                                      *
 * Free use of the General Purpose Hash Function Algorithms Library is    *
 * permitted under the guidelines and in accordance with the MIT License. *
 * http://www.opensource.org/licenses/MIT                                 *
 *                                                                        *
 **************************************************************************
*/

unsigned int RSHash(const string& str)
{
   unsigned int b    = 378551;
   unsigned int a    = 63689;
   unsigned int hash = 0;

   for(size_t i = 0; i < str.length(); i++)
   {
      hash = hash * a + str[i];
      a    = a * b;
   }

   return hash;
}
/* End Of RS Hash Function */


unsigned int JSHash(const string& str)
{
   unsigned int hash = 1315423911;

   for(size_t i = 0; i < str.length(); i++)
   {
      hash ^= ((hash << 5) + str[i] + (hash >> 2));
   }

   return hash;
}
/* End Of JS Hash Function */


unsigned int PJWHash(const string& str)
{
   unsigned int BitsInUnsignedInt = (unsigned int)(sizeof(unsigned int) * 8);
   unsigned int ThreeQuarters     = (unsigned int)((BitsInUnsignedInt  * 3) / 4);
   unsigned int OneEighth         = (unsigned int)(BitsInUnsignedInt / 8);
   unsigned int HighBits          = (unsigned int)(0xFFFFFFFF) << (BitsInUnsignedInt - OneEighth);
   unsigned int hash              = 0;
   unsigned int test              = 0;

   for(size_t i = 0; i < str.length(); i++)
   {
      hash = (hash << OneEighth) + str[i];

      if((test = hash & HighBits)  != 0)
      {
         hash = (( hash ^ (test >> ThreeQuarters)) & (~HighBits));
      }
   }

   return hash;
}
/* End Of  P. J. Weinberger Hash Function */


unsigned int ELFHash(const string& str)
{
   unsigned int hash = 0;
   unsigned int x    = 0;

   for(size_t i = 0; i < str.length(); i++)
   {
      hash = (hash << 4) + str[i];
      if((x = hash & 0xF0000000L) != 0)
      {
         hash ^= (x >> 24);
      }
      hash &= ~x;
   }

   return hash;
}
/* End Of ELF Hash Function */


unsigned int BKDRHash(const string& str)
{
   unsigned int seed = 131; // 31 131 1313 13131 131313 etc..
   unsigned int hash = 0;

   for(size_t i = 0; i < str.length(); i++)
   {
      hash = (hash * seed) + str[i];
   }

   return hash;
}
/* End Of BKDR Hash Function */


unsigned int SDBMHash(const string& str)
{
   unsigned int hash = 0;

   for(size_t i = 0; i < str.length(); i++)
   {
      hash = str[i] + (hash << 6) + (hash << 16) - hash;
   }

   return hash;
}
/* End Of SDBM Hash Function */


unsigned int DJBHash(const string& str)
{
   unsigned int hash = 5381;

   for(size_t i = 0; i < str.length(); i++)
   {
      hash = ((hash << 5) + hash) + str[i];
   }

   return hash;
}
/* End Of DJB Hash Function */


unsigned int DEKHash(const string& str)
{
   unsigned int hash = static_cast<unsigned int>(str.length());

   for(size_t i = 0; i < str.length(); i++)
   {
      hash = ((hash << 5) ^ (hash >> 27)) ^ str[i];
   }

   return hash;
}
/* End Of DEK Hash Function */


unsigned int BPHash(const string& str)
{
   unsigned int hash = 0;
   for(size_t i = 0; i < str.length(); i++)
   {
      hash = hash << 7 ^ str[i];
   }

   return hash;
}
/* End Of BP Hash Function */


unsigned int FNVHash(const string& str)
{
   const unsigned int fnv_prime = 0x811C9DC5;
   unsigned int hash = 0;
   for(size_t i = 0; i < str.length(); i++)
   {
      hash *= fnv_prime;
      hash ^= str[i];
   }

   return hash;
}
/* End Of FNV Hash Function */


unsigned int APHash(const string& str)
{
   unsigned int hash = 0xAAAAAAAA;

   for(size_t i = 0; i < str.length(); i++)
   {
      hash ^= ((i & 1) == 0) ? (  (hash <<  7) ^ str[i] * (hash >> 3)) :
                               (~((hash << 11) + (str[i] ^ (hash >> 5))));
   }

   return hash;
}
/* End Of AP Hash Function */
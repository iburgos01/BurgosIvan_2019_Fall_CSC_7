/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.h
 * Author: Ivan Burgos
 * Created on October 10, 2019, 10:00 AM
 * Purpose: Specification for MasterMind Game
 */

#ifndef GAME_H
#define GAME_H

class Game{
    private:
        int size,nguess;
        const int ROW,COL;
        int *guess;
        int *pos;
        char colors[][];
    public:
        Game(int);
        ~Game();
        void StartNew(int, bool);
        void play();
};

#endif /* GAME_H */

